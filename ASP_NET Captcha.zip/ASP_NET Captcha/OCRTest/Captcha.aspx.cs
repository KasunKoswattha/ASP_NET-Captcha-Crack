﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace CaptchaTest
{
    public partial class Captcha : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                int result = GetRandom();
                bool isValid = ucCaptcha.Validate(result.ToString());

                while (!isValid)
                {
                    result = GetRandom();
                    isValid = ucCaptcha.Validate(result.ToString());
                }
                if (isValid)
                {
                    lblMessage.Text = "Valid!!! The Number is " + result;
                    lblMessage.ForeColor = Color.Green;
                }
                else
                {
                    lblMessage.Text = "Invalid!";
                    lblMessage.ForeColor = Color.Red;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            
        }


        private int GetRandom()
        {
            int number = 0;
            try
            {
                Random rnd = new Random();
                number = rnd.Next(0, 38);
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {

            }
            return number;
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            lblMessage.Text = string.Empty;
        }
        
    }
}